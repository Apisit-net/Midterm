class DiscountedProduct extends Product {
    constructor(
        name: string,
        price: number,
        category: string,
        public discountRate: number // percentage discount
    ) {
        super(name, price, category);
    }

    getProductInfo(): string {
        const discountAmount = (this.discountRate / 100) * this.price;
        const finalPrice = this.price - discountAmount;
        return `Name: ${this.name}, Original Price: $${this.price.toFixed(2)}, Discount: ${this.discountRate}%, Final Price: $${finalPrice.toFixed(2)}, Category: ${this.category}`;
    }
}

// Example usage
const discountedProduct = new DiscountedProduct("Smartphone", 800, "Electronics", 10);
console.log(discountedProduct.getProductInfo());
