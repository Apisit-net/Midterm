function parseProductData(jsonData: string): string | object {
    try {
        return JSON.parse(jsonData);
    } catch (error) {
        return `Error parsing JSON data: ${error.message}`;
    }
}

// Example usage
const validJson = '{"name": "Watch", "price": 250, "category": "Accessories"}';
const invalidJson = '{"name": "Watch", "price": 250, "category": "Accessories"';

console.log(parseProductData(validJson));
console.log(parseProductData(invalidJson));
