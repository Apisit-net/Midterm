interface Customer {
    name: string;
    email: string;
    orders: Product[];
}

function getCustomerInfo(customer: Customer): void {
    console.log(`Customer: ${customer.name}, Email: ${customer.email}, Orders placed: ${customer.orders.length}`);
}

// Example usage
const customer: Customer = {
    name: "John Doe",
    email: "john@example.com",
    orders: [product1, discountedProduct]
};

getCustomerInfo(customer);
