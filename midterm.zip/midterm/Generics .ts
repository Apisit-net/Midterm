class Inventory<T> {
    private items: T[] = [];

    addItem(item: T): void {
        this.items.push(item);
    }

    listItems(): T[] {
        return this.items;
    }
}

// Example usage
const productInventory = new Inventory<Product>();
productInventory.addItem(product1);
productInventory.addItem(discountedProduct);
console.log(productInventory.listItems());
