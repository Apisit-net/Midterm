const products = [product1, discountedProduct];

// filter() to return only products priced above 100
const expensiveProducts = products.filter(product => product.price > 100);
console.log(expensiveProducts);

// map() to create an array of product names
const productNames = products.map(product => product.name);
console.log(productNames);

// reduce() to calculate the total cost of all products in the array
const totalCost = products.reduce((sum, product) => sum + product.price, 0);
console.log(`Total cost of products: $${totalCost.toFixed(2)}`);
