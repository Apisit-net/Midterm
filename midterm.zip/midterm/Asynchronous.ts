async function fetchProductData(): Promise<void> {
    try {
        // Simulate API call
        const productData = await new Promise<{ name: string, price: number, category: string }>((resolve, reject) => {
            setTimeout(() => {
                resolve({ name: "Tablet", price: 500, category: "Electronics" });
            }, 2000);
        });

        console.log(`Product fetched: Name: ${productData.name}, Price: $${productData.price.toFixed(2)}, Category: ${productData.category}`);
    } catch (error) {
        console.error("Error fetching product data:", error);
    }
}

// Example usage
fetchProductData();
