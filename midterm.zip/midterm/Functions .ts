function createPriceMultiplier(multiplier: number): (price: number) => number {
    return (price: number) => price * multiplier;
}

const applyTax = createPriceMultiplier(1.07);

// Example usage
console.log(`Price after tax: $${applyTax(product1.price).toFixed(2)}`);
