class Product {
    private static productCount: number = 0;
    constructor(
        public name: string,
        public price: number,
        public category: string
    ) {
        Product.productCount++;
    }

    updatePrice(newPrice: number): void {
        this.price = newPrice;
    }

    getProductInfo(): string {
        return `Name: ${this.name}, Price: $${this.price.toFixed(2)}, Category: ${this.category}`;
    }

    static totalProducts(): number {
        return Product.productCount;
    }
}

// Example usage
const product1 = new Product("Laptop", 1200, "Electronics");
console.log(product1.getProductInfo());
product1.updatePrice(1100);
console.log(product1.getProductInfo());
console.log(Product.totalProducts());
